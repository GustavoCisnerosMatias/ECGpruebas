import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RegistraradministradorPage } from './registraradministrador.page';

describe('RegistraradministradorPage', () => {
  let component: RegistraradministradorPage;
  let fixture: ComponentFixture<RegistraradministradorPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistraradministradorPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
