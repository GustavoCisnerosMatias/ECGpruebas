import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-historial-medi-paci',
  templateUrl: './historial-medi-paci.page.html',
  styleUrls: ['./historial-medi-paci.page.scss'],
})
export class HistorialMediPaciPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
