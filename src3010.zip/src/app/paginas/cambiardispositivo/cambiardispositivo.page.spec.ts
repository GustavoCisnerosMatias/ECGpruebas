import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CambiardispositivoPage } from './cambiardispositivo.page';

describe('CambiardispositivoPage', () => {
  let component: CambiardispositivoPage;
  let fixture: ComponentFixture<CambiardispositivoPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(CambiardispositivoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
