import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CambiardispositivoPageRoutingModule } from './cambiardispositivo-routing.module';

import { CambiardispositivoPage } from './cambiardispositivo.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CambiardispositivoPageRoutingModule
  ],
  declarations: [CambiardispositivoPage]
})
export class CambiardispositivoPageModule {}
