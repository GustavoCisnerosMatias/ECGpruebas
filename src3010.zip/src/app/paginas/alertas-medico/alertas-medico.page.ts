import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertasService } from 'src/app/servicios/alertas.service';

@Component({
  selector: 'app-alertas-medico',
  templateUrl: './alertas-medico.page.html',
  styleUrls: ['./alertas-medico.page.scss'],
})
export class AlertasMedicoPage implements OnInit {
  parametro: any;
  paciente: any;
  alertas: any[] = [];  // Para almacenar las alertas del paciente

  constructor(
    private router: Router, 
    private alertasService: AlertasService
  ) {}

  ngOnInit() {
    this.obtenerDatos();
  }

  obtenerDatos() {
    const navigation = this.router.getCurrentNavigation();
    if (navigation && navigation.extras.state) {
      const state = navigation.extras.state as { parametro: any, paciente: any };
      if (state) {
        this.parametro = state.parametro;
        this.paciente = state.paciente;
        console.log('Parametro recibido:', this.parametro);
        console.log('Paciente recibido:', this.paciente);

        // Cargar alertas para el paciente
        this.cargarAlertasPaciente(this.paciente.id_usuario);
      } else {
        console.error('No se recibieron datos del parámetro o paciente');
      }
    }
  }

  cargarAlertasPaciente(id_usuario: number) {
    this.alertasService.obtenerAlertas(id_usuario).subscribe(response => {
      this.alertas = response.Alertas.sort((a, b) => {
        // Convertir las fechas a objetos Date para compararlas
        const dateA = new Date(a.fecha_alerta).getTime();
        const dateB = new Date(b.fecha_alerta).getTime();
        
        // Ordenar en orden descendente (última alerta primero)
        return dateB - dateA;
      });
      console.log('Alertas ordenadas:', this.alertas);
    }, error => {
      console.error('Error al cargar alertas', error);
    });
  }
}
