import { ComponentFixture, TestBed } from '@angular/core/testing';
import { EditartodousuarioPage } from './editartodousuario.page';

describe('EditartodousuarioPage', () => {
  let component: EditartodousuarioPage;
  let fixture: ComponentFixture<EditartodousuarioPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(EditartodousuarioPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
