import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DatostiemporealPage } from './datostiemporeal.page';

describe('DatostiemporealPage', () => {
  let component: DatostiemporealPage;
  let fixture: ComponentFixture<DatostiemporealPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(DatostiemporealPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
