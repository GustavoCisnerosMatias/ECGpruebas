import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IMenu } from 'src/app/interfaces/interface';
import { AlertasService } from 'src/app/servicios/alertas.service';
import { SerAutentificacionService } from 'src/app/servicios/ser-autentificacion.service';
import { UsuariosService } from 'src/app/servicios/usuarios.service';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.page.html',
  styleUrls: ['./inicio.page.scss'],
})
export class InicioPage implements OnInit {
  usuarioActual: any | null = null;
  menuOpciones: IMenu[] = [];
  nuevasAlertas: boolean = false;
  mostrarAlertas: boolean = false; // Para controlar si se muestra el componente de alertas
  mostrarParametros: boolean = false; // Para controlar si se muestra el componente ParametrosComponent

  constructor(
    public router: Router,
    private serAutentificacion: SerAutentificacionService,
    private alertasService: AlertasService,
    private usuariosService: UsuariosService,
  ) {}

  ngOnInit() {
    this.menuOpciones = this.serAutentificacion.menu.filter(opcion => opcion.categoria === 1);
    this.cargarUsuarioActual();
  
    // Verificar si el idRol del usuario es igual a 1
    if (this.serAutentificacion.idRol === 1) {
      this.alertasService.alertas$.subscribe(alertas => {
        this.nuevasAlertas = alertas.some(alerta => alerta.vista === 'Nuevo');
      });
    }
    
    this.cargarAlertas(); // Cargar alertas al iniciar
  }
  

  cargarUsuarioActual() {
    this.usuarioActual = this.usuariosService.getUsuarioActual();
    if (!this.usuarioActual || !this.usuarioActual.id_usuario) {
      console.error('No se pudo cargar el usuario actual');
    }
  }

  cargarAlertas() {
    if (this.usuarioActual) {
      this.alertasService.cargarAlertas(this.usuarioActual.id_usuario);
    }
  }

  toggleAlertas() {
    this.mostrarAlertas = !this.mostrarAlertas;
    if (this.mostrarAlertas && this.usuarioActual) {
      this.cargarAlertas();
    }
  }

  navegar(men_pagina: string) {
    console.log('Página seleccionada:', men_pagina);
    
    if (men_pagina === '/alertas') {
      this.mostrarAlertas = !this.mostrarAlertas;
      this.mostrarParametros = false; // Oculta ParametrosComponent cuando se muestran las alertas
      if (this.mostrarAlertas && this.usuarioActual) {
        this.cargarAlertas();
      }
    } else if (men_pagina === '/realtime') {
      console.log('Mostrando parámetros');
      this.mostrarParametros = !this.mostrarParametros;
      this.mostrarAlertas = false; // Oculta AlertasComponent cuando se muestran los parámetros
    } else {
      console.log('Navegando a otra página:', men_pagina);
      this.mostrarAlertas = false;
      this.mostrarParametros = false;
      this.router.navigate([men_pagina]);
    }
  }
  
  salir() {
   this.serAutentificacion.logout();
  }


  tago() {
    this.router.navigate(['/datostago']);
    
  }
  realtime() {
    
    this.router.navigate(['/realtime']);
  }
}
