import { Component, OnInit } from '@angular/core';
import { AlertasService } from 'src/app/servicios/alertas.service';
import { alertas } from 'src/app/interfaces/interface';

@Component({
  selector: 'app-todasalertas',
  templateUrl: './todasalertas.page.html',
  styleUrls: ['./todasalertas.page.scss'],
})
export class TodasalertasPage implements OnInit {
  alertas: alertas[] = [];
  filteredAlertas: alertas[] = [];
  searchName: string = '';
  startDate: string = '';
  endDate: string = '';

  constructor(private alertasService: AlertasService) { }

  ngOnInit() {
    this.cargarAlertas();
  }

  cargarAlertas() {
    // Suscribirse al observable de alertas del servicio
    this.alertasService.alertas$.subscribe((alertas) => {
      this.alertas = alertas; // Actualizar la lista de alertas
      this.filterAlertas(); // Aplicar el filtro inicial
      console.log(this.alertas); // Verifica que las alertas se cargan correctamente
    });
  }

  filterAlertas() {
    let filtered = this.alertas;

    // Filtro por nombre
    if (this.searchName) {
      filtered = filtered.filter(alerta =>
        alerta.nombre_alerta.toLowerCase().includes(this.searchName.toLowerCase())
      );
    }

    // Filtro por fecha
    if (this.startDate && this.endDate) {
      filtered = filtered.filter(alerta => {
        const alertaDate = alerta.fecha_alerta.split(' ')[0]; // Solo fecha en YYYY-MM-DD
        return alertaDate >= this.startDate && alertaDate <= this.endDate;
      });
    }

    this.filteredAlertas = filtered;
  }

  formatFecha(fecha: string): string {
    return fecha.split(' ')[0]; // Retorna solo la fecha en YYYY-MM-DD
  }
}
