import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IonicModule, ToastController } from '@ionic/angular';
import { MedicoService } from 'src/app/servicios/medico.service';
import { UsuariosService } from 'src/app/servicios/usuarios.service';
import * as moment from 'moment';
import { ChartData, ChartOptions, registerables, Chart } from 'chart.js';
import 'chartjs-adapter-date-fns';

Chart.register(...registerables);

@Component({
  selector: 'app-reporte-ttl-pacientes',
  templateUrl: './reporte-ttl-pacientes.component.html',
  styleUrls: ['./reporte-ttl-pacientes.component.scss'],
})
export class ReporteTtlPacientesComponent implements OnInit {
  listaMedicos: any[] = [];
  usuarioActual: any | null = null;
  medicosPorUsuario: any[] = [];
  estadisticasPorAnio: any[] = [];
  pacientesPorMes: { [key: string]: number } = {}; // Ensure type safety
  meses: string[] = [];
  conteoPacientesPorMes: number[] = [];
  estadisticasPorMes: any[] = [];
  totalPacientes: number = 0;
  anios: number[] = [];
  totalPacientesPorAnio: number[] = [];
  
  constructor(
    private router: Router,
    private usuariosService: UsuariosService,
    private medicoService: MedicoService,
    private toastController: ToastController
  ) {}

  ngOnInit() {
    this.obtenerMedicos();
    this.cargarUsuarioActual();
  }

  cargarUsuarioActual() {
    this.usuarioActual = this.usuariosService.getUsuarioActual();
    if (this.usuarioActual?.id_usuario) {
      this.obtenerPacientesPorUsuario(this.usuarioActual.id_usuario);
    }
  }

  obtenerMedicos() {
    this.medicoService.obtenerMedicos().subscribe(
      (response) => {
        this.listaMedicos = response.medicos;
      },
      (error) => {
        this.mostrarMensaje('Error al obtener la lista de médicos');
        console.error('Error al obtener la lista de médicos', error);
      }
    );
  }

  obtenerPacientesPorUsuario(id_usuario: number) {
    this.medicoService.obtenerpacientes(id_usuario).subscribe(
      (response) => {
        this.medicosPorUsuario = response;
        this.generarEstadisticas();
      },
      (error) => {
        this.mostrarMensaje('Error al obtener pacientes por usuario');
        console.error('Error al obtener pacientes por usuario', error);
      }
    );
  }

  async mostrarMensaje(mensaje: string) {
    const toast = await this.toastController.create({
      message: mensaje,
      duration: 2000,
      position: 'bottom'
    });
    toast.present();
  }

  generarEstadisticas() {
    this.pacientesPorMes = {};
    this.totalPacientes = 0;

    const anioActual = moment().year();

    // Recorre la lista de médicos para contar pacientes por mes
    this.medicosPorUsuario.forEach(paciente => {
        const fechaRegistro = moment(paciente.fecha_registro); // Asegúrate de que esta línea sea correcta

        // Verifica que la fecha se haya parseado correctamente
        if (!fechaRegistro.isValid()) {
            console.error(`Fecha inválida: ${paciente.fecha_registro}`);
            return; // Salir si la fecha no es válida
        }

        // Asegúrate de que la fecha esté en el año actual
        if (fechaRegistro.year() === anioActual) {
            // Formato del mes (ej: "Septiembre 2024")
            const mes = fechaRegistro.format('MMMM YYYY');
            this.pacientesPorMes[mes] = (this.pacientesPorMes[mes] || 0) + 1;
            this.totalPacientes++;
        }
    });

    console.log('Pacientes por mes antes de ordenar:', this.pacientesPorMes);

    // Obtener los meses en orden natural
    const mesesDelAnio = moment.months(); // Esto te da un array de todos los meses
    this.meses = mesesDelAnio.map(mes => `${mes} ${anioActual}`)
        .filter(mes => mes in this.pacientesPorMes); // Filtrar meses que tienen pacientes

    // Verifica qué meses se están utilizando
    console.log('Meses después del filtrado:', this.meses);

    // Obtener conteo de pacientes por mes
    this.conteoPacientesPorMes = this.meses.map(mes => this.pacientesPorMes[mes] || 0); // Asegurarse de que se muestren 0 si no hay pacientes

    // Asegúrate de que conteoPacientesPorMes tenga los valores correctos
    console.log('Conteo de pacientes por mes:', this.conteoPacientesPorMes);

    // Calcular estadísticas adicionales
    this.calcularEstadisticasDetalladas();
    this.calcularTotalPacientesPorAnio();
    this.calcularEstadisticasPorAnio();

    console.log('Estadísticas de pacientes por mes:', this.pacientesPorMes);
}

  calcularEstadisticasDetalladas() {
    let pacientesAcumulados = 0;
    let pacientesPrevioMes: number | null = null;

    this.estadisticasPorMes = this.meses.map((mes, index) => {
      const pacientesNuevos = this.pacientesPorMes[mes];
      pacientesAcumulados += pacientesNuevos;

      const cambioMensual = pacientesPrevioMes !== null 
        ? (((pacientesNuevos - pacientesPrevioMes) / pacientesPrevioMes) * 100).toFixed(2) + '%'
        : '-';
      
      pacientesPrevioMes = pacientesNuevos;

      return {
        mes,
        pacientesNuevos,
        totalPacientes: pacientesAcumulados,
        cambioMensual
      };
    });
  }

  calcularTotalPacientesPorAnio() {
    const pacientesPorAnio: { [key: number]: number } = {};

    this.medicosPorUsuario.forEach(paciente => {
      const fechaRegistro = moment(paciente.fecha_registro);
      const anio = fechaRegistro.year();

      if (!pacientesPorAnio[anio]) {
        pacientesPorAnio[anio] = 0;
      }

      pacientesPorAnio[anio]++;
    });

    this.anios = Object.keys(pacientesPorAnio).map(Number);
    this.totalPacientesPorAnio = this.anios.map(anio => pacientesPorAnio[anio]);
  }

  calcularEstadisticasPorAnio() {
    const pacientesPorAnio: { [key: number]: number } = {};
    let pacientesAcumulados = 0;
    let pacientesPrevioAnio: number | null = null;

    this.medicosPorUsuario.forEach(paciente => {
        const fechaRegistro = moment(paciente.fecha_registro);
        const anio = fechaRegistro.year();

        if (!pacientesPorAnio[anio]) {
            pacientesPorAnio[anio] = 0;
        }

        pacientesPorAnio[anio]++;
    });

    this.estadisticasPorAnio = Object.keys(pacientesPorAnio).map(anioStr => {
        const anio = Number(anioStr);
        const pacientesNuevos = pacientesPorAnio[anio];
        pacientesAcumulados += pacientesNuevos;

        // Cálculo de la tasa de crecimiento poblacional anual usando la fórmula
        let cambioAnual: string | number = '-';
        if (pacientesPrevioAnio !== null) {
            const P_x = pacientesAcumulados; // Población en el año final
            const P_0 = pacientesPrevioAnio; // Población en el año inicial
            const t = 1; // Suponiendo que estamos calculando para un año

            // Aplicar la fórmula
            const tasaCrecimiento = ((P_x / P_0) ** (1 / t) - 1) * 100;
            cambioAnual = tasaCrecimiento.toFixed(2) + '%'; // Formato de porcentaje
        }

        // Actualizar pacientesPrevioAnio al total acumulado
        pacientesPrevioAnio = pacientesAcumulados;

        return {
            anio,
            pacientesNuevos,
            totalPacientes: pacientesAcumulados,
            cambioAnual
        };
    });
}


}
