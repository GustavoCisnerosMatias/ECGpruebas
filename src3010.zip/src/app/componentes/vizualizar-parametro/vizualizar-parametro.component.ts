/////////////////////////aqui



import { Component, Injector, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ParametrosService } from 'src/app/servicios/parametros.service';
import { DatoBiome } from 'src/app/interfaces/interface';
import { ChartData, ChartOptions, registerables, Chart, ChartType } from 'chart.js';

@Component({
  selector: 'app-vizualizar-parametro',
  templateUrl: './vizualizar-parametro.component.html',
  styleUrls: ['./vizualizar-parametro.component.scss'],
})
export class VizualizarParametroComponent implements OnInit {
  parametro: any;
  paciente: any;
  fechaIni: string = '';
  fechaFin: string = '';
  datos: DatoBiome[] = [];

  mostrarSelectorInicio: boolean = false;
  mostrarSelectorFin: boolean = false;

  public chartData: any[] = [];
  public chartLabels: string[] = [];
  public chartOptions: ChartOptions = {
    responsive: true,
  };
  public chartType: ChartType = 'line'; 
  tipoGrafico: string = 'linea';
  //selectedChartType: string = 'line';


  constructor(
    private injector: Injector,
    private router: Router,
    private parametrosService: ParametrosService
  ) {}

  ngOnInit() {
    this.parametro = this.injector.get('parametro');
    this.paciente = this.injector.get('paciente');
    console.log('Parametro recibido:', this.parametro);
    console.log('Paciente recibido:', this.paciente);
    this.obtenerDatos();
  }

  obtenerDatos() {
    if (this.parametro && this.paciente) {
      this.obtenerDatosDelServicio();
    } else {
      console.error('No se recibieron datos del parámetro o paciente');
    }
  }
  actualizarGrafico() {
    // Aquí puedes agregar lógica para actualizar los gráficos si es necesario
    console.log(`Tipo de gráfico seleccionado: ${this.tipoGrafico}`);
  }

  obtenerDatosDelServicio() {
    if (this.fechaIni && this.fechaFin) {
      const requestData = {
        id_usuario: this.paciente.id_usuario,
        id_parametro: this.parametro.id_parametro,
        fecha_ini: this.formatDate(this.fechaIni),
        fecha_fin: this.formatDate(this.fechaFin),
      };
  
      this.parametrosService.obtenerdatosbiome(requestData).subscribe(
        (response: any) => {
          console.log('Respuesta completa:', response);
          this.datos = response;
  
          // Agrupar datos por hora
          const groupedData: { [key: string]: number[] } = {};
          this.datos.forEach(dato => {
            // Obtener la fecha y hora (sin minutos y segundos)
            const date = new Date(dato.fecha);
            const hourKey = `${date.toISOString().split('T')[0]} ${date.getHours()}`; // Formato: YYYY-MM-DD HH
  
            // Agrupar los valores por hora
            if (!groupedData[hourKey]) {
              groupedData[hourKey] = [];
            }
            groupedData[hourKey].push(parseFloat(dato.valor));
          });
  
          // Calcular el promedio por hora
          this.chartLabels = Object.keys(groupedData);
          this.chartData = [{
            data: this.chartLabels.map(label => {
              const values = groupedData[label];
              const average = values.reduce((sum, value) => sum + value, 0) / values.length; // Calcular promedio
              return average || 0; // Devolver 0 si el promedio es NaN
            }),
            label: 'Promedio de Temperatura', // Cambia esto según el parámetro
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 2,
            fill: true,
          }];
        },
        (error) => {
          console.error('Error al obtener los datos:', error);
        }
      );
    }
  }
  

  
  
  // Método para formatear la fecha
  private formatDate(fecha: string): string {
    return fecha ? fecha.split('T')[0] : ''; // Devuelve solo la parte de fecha
  }
  

  toggleDateSelectors() {
    this.mostrarSelectorInicio = !this.mostrarSelectorInicio;
    this.mostrarSelectorFin = !this.mostrarSelectorFin;
  }
  cerrarSelector(tipo: string) {
    if (tipo === 'inicio') {
      this.mostrarSelectorInicio = false; // Oculta el selector de inicio
    } else if (tipo === 'fin') {
      this.mostrarSelectorFin = false; // Oculta el selector de fin
    }
  }
  onChartTypeChange() {
    this.chartOptions.scales = {}; 
    console.log('Tipo de gráfico cambiado a:', this.chartType);
    this.obtenerDatosDelServicio(); // Reobtenemos los datos para actualizar el gráfico
  }
  
}
