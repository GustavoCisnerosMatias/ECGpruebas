import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-consulta-compo',
  templateUrl: './consulta-compo.component.html',
  styleUrls: ['./consulta-compo.component.scss'],
})
export class ConsultaCompoComponent  implements OnInit {
  @Input() paciente: any; 
  constructor() { }

  ngOnInit() {}

}
