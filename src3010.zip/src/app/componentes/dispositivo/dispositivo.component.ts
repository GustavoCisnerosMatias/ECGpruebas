import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-dispositivo',
  templateUrl: './dispositivo.component.html',
  styleUrls: ['./dispositivo.component.scss'],
})
export class DispositivoComponent {
  dispositivo: any = {
    //id_usuario: 1,
    codigo: '',
    nombre: '',
    estado: 'A'
  };

  @Output() dispositivoCreado = new EventEmitter<any>();
  @Output() anterior = new EventEmitter<void>();  
  @Input() datos: any;  // Nuevo Input para recibir los datos

  siguiente() {
    this.dispositivoCreado.emit(this.dispositivo);
  }
  retroceder() {
    this.anterior.emit();
  }
}
