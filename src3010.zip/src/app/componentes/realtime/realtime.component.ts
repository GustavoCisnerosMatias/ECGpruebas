import { Component, OnDestroy } from '@angular/core';
import { MqttService, IMqttMessage } from 'ngx-mqtt';
import { Dato, DatoBiome, ITopic } from 'src/app/interfaces/interface';
import { SerAutentificacionService } from 'src/app/servicios/ser-autentificacion.service';
import { Subscription } from 'rxjs';
import { ParametrosService } from 'src/app/servicios/parametros.service';
import { Parametro, RespuestaParametros } from 'src/app/interfaces/interface';

@Component({
  selector: 'app-realtime',
  templateUrl: './realtime.component.html',
  styleUrls: ['./realtime.component.scss'],
})
export class RealtimeComponent implements OnDestroy {
  latestData: any = null;
  dataHistory: any[] = [];
  Topic: ITopic[] = [];
  datos: Dato [] = [];
  otrosParametros: any[] = [];
  parametros: any[] = [];
  mensajeError: string | null = null; // Mensaje de error
  imc: number | null = null; // Almacena el valor del IMC
  descripcionIMC: string = ''; // Descripción del IMC
  pesoIdealMin: number | null = null; // Peso ideal mínimo
  pesoIdealMax: number | null = null; // Peso ideal máximo

  showTooltip: boolean = false;


  usuarioActual: any | null = null;
  datosFisicos: any = {}; // Almacena peso y estatura
  idUsuario: string | null = null;
  private subscriptions: Subscription[] = []; // Lista para almacenar las suscripciones

  constructor(private mqttService: MqttService, private serM: SerAutentificacionService,private parametrosService: ParametrosService) {}

  ngOnInit() {
    this.Topic = this.serM.getTopics(); // Obtener los tópicos del servicio
    console.log(this.Topic);
    this.Topic.forEach(topic => {
      if (topic && topic.nombre) { // Asegúrate de que el nombre del tópico esté definido
        this.subscribeToTopic(topic.nombre); // Suscribirse a cada tópico
      } else {
        console.error('Nombre del tópico no definido:', topic);
      }
    });

    this.cargarDatosFisicos();
    this.cargarParametros();
  }
  obtenerNombreParametro(id: number): string {
    const parametro = this.parametros.find(p => p.id_parametro === id);
    return parametro ? parametro.nombre : 'Desconocido'; // Devuelve un nombre por defecto si no se encuentra
  }
  
  /* subscribeToTopic(topic: string) {
    const subscription = this.mqttService.observe(topic).subscribe((message: IMqttMessage) => {
      const data = JSON.parse(message.payload.toString());
      this.latestData = data;
      this.dataHistory.push(data);
      console.log(data); // Para verificar los datos recibidos
    });

    this.subscriptions.push(subscription); // Almacenar la suscripción en la lista
  } */
    subscribeToTopic(topic: string) {
      const subscription = this.mqttService.observe(topic).subscribe((message: IMqttMessage) => {
        const data = JSON.parse(message.payload.toString());
        console.log('Datos recibidos:', data); // Verifica los datos recibidos
    
        // Asegúrate de que `data` es un array
        if (Array.isArray(data)) {
          this.latestData = data;
          this.dataHistory.push(...data);
          
          // Agregar todos los datos recibidos al array `datos`
          data.forEach((dato: Dato) => {
            if (dato.id_parametro) {
              const index = this.datos.findIndex(d => d.id_parametro === dato.id_parametro);
              if (index !== -1) {
                this.datos[index] = dato; // Actualiza el valor
              } else {
                this.datos.push(dato); // Agrega nuevo dato
              }
            }
          });
        } else {
          console.warn('Los datos no son un array:', data);
        }
      });
    
      this.subscriptions.push(subscription); // Almacenar la suscripción en la lista
    }
    
    cargarParametros() {
      this.parametrosService.obtenerParametros().subscribe((data: RespuestaParametros) => {
        console.log('Datos recibidos:', data);
        this.parametros = data.datos;
        const nombres = this.parametros.map(p => p.nombre);
  
      // Filtra los parámetros para mostrar solo los no relacionados con la presión arterial
      this.otrosParametros = this.parametros.filter(p => p.nombre !== 'presión_Sistolica' && p.nombre !== 'presión_Diastolica');
      });
    }
    

  ngOnDestroy() {
    // Cancelar todas las suscripciones cuando el componente se destruya
    this.subscriptions.forEach(sub => sub.unsubscribe());
    console.log('Todas las suscripciones a MQTT se han cancelado');
  }


  cargarDatosFisicos() {
    this.datosFisicos = this.serM.datosfisicos[0] || {}; // Asigna el primer dato de datosfisicos
    if (this.datosFisicos.peso && this.datosFisicos.estatura) {
      this.calcularIMC(this.datosFisicos.peso, this.datosFisicos.estatura);
    } else {
      console.error('Datos de peso o estatura no encontrados');
      this.mensajeError = 'Datos de peso o estatura no encontrados';
    }
  }

  //calculo peso
  calcularIMC(peso: number, estatura: number) {
    // Convertir estatura a metros si está en centímetros
    
    this.imc = peso / (estatura * estatura);
  
    // Calcular el peso ideal basado en un rango de IMC de 18.5 a 24.9
    this.pesoIdealMin = 18.5 * (estatura * estatura);
    this.pesoIdealMax = 24.9 * (estatura * estatura);
  
    // Determinar la descripción del IMC
    if (this.imc < 18.5) {
      this.descripcionIMC = 'Peso bajo';
    } else if (this.imc >= 18.5 && this.imc < 25) {
      this.descripcionIMC = 'Peso normal';
    } else if (this.imc >= 25 && this.imc < 30) {
      this.descripcionIMC = 'Sobrepeso';
    } else if (this.imc >= 30 && this.imc < 40) {
      this.descripcionIMC = 'Obesidad';
    } else {
      this.descripcionIMC = 'Obesidad mórbida';
    }
  }
  
  getCardClass(variable: number): string {
    switch (variable) {
      case 1:
        return 'card-temperatura';
      case 2:
        return 'card-frecuencia';
      case 5:
        return 'card-saturacion';
      default:
        return 'card-default';
    }
  }

}
