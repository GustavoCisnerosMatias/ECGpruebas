import { Component, Input, OnInit } from '@angular/core';
import { PacienteService } from 'src/app/servicios/paciente.service';
// Asegúrate de importar el servicio

@Component({
  selector: 'app-antece-person',
  templateUrl: './antece-person.component.html',
  styleUrls: ['./antece-person.component.scss'],
})
export class AntecePersonComponent implements OnInit {
  @Input() paciente: any; 
  antecedentes: any[] = []; // Almacena los antecedentes

  constructor(private pacienteService: PacienteService) { }

  ngOnInit() {
    if (this.paciente) {
      this.obtenerAntecedentes(this.paciente.id_usuario); // Llama a la función para obtener antecedentes
    }
  }

  obtenerAntecedentes(id_paciente: number) {
    this.pacienteService.Obtenerantecepersonal(id_paciente).subscribe(
      (response) => {
        this.antecedentes = response; // Almacena la respuesta en la propiedad antecedentes
      },
      (error) => {
        console.error('Error al obtener antecedentes:', error); // Maneja el error
      }
    );
  }
  openConsultation() {
    const url = 'https://icd.who.int/browse10/2019/en#/A15-A19';
    window.open(url, '_blank'); // Abre el enlace en una nueva pestaña.
  }
}
