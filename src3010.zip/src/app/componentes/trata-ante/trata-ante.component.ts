import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-trata-ante',
  templateUrl: './trata-ante.component.html',
  styleUrls: ['./trata-ante.component.scss'],
})
export class TrataAnteComponent  implements OnInit {
  @Input() paciente: any; 
  constructor() { }

  ngOnInit() {}

}
