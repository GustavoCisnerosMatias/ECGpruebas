import { Component, EventEmitter, Output, Input } from '@angular/core';
import { UsuariosService } from 'src/app/servicios/usuarios.service';

@Component({
  selector: 'app-datos-fisicos',
  templateUrl: './datos-fisicos.component.html',
  styleUrls: ['./datos-fisicos.component.scss'],
})
export class DatosFisicosComponent {
  @Output() datosFisicosCreado = new EventEmitter<any>();
  @Output() anterior = new EventEmitter<void>();
  @Input() datos: any;  // Input para recibir los datos iniciales

  datosFisicos: any = {
    peso: '',
    estatura: '',
    nivel_condicion_fisica: ''
  };
  estaturas: number[] = [];
  pesos: number[] = [];
  errorMensaje: string = '';  // Variable para manejar mensajes de error

  constructor(private usuariosService: UsuariosService) {}

  ngOnInit() {
    this.cargarEstaturas();
    this.cargarPesos();
    if (this.datos) {
      this.datosFisicos = { ...this.datos };
    }
  }

  cargarEstaturas() {
    this.usuariosService.obtenerEstaturas().subscribe(
      (data: any) => {
        this.estaturas = data.estaturas;
      },
      (error) => {
        console.error('Error al cargar las estaturas', error);
      }
    );
  }

  cargarPesos() {
    this.usuariosService.obtenerPesos().subscribe(
      (data: any) => {
        this.pesos = data.pesos;
      },
      (error) => {
        console.error('Error al cargar los pesos', error);
      }
    );
  }

  registrarDatosFisicos() {
    // Validar que todos los campos estén completos antes de emitir el evento
    if (this.datosFisicos.peso && this.datosFisicos.estatura && this.datosFisicos.nivel_condicion_fisica) {
      this.datosFisicosCreado.emit(this.datosFisicos);
      this.errorMensaje = '';  // Limpiar el mensaje de error si todo está bien
    } else {
      this.errorMensaje = 'Por favor, complete todos los campos antes de continuar.';
    }
  }

  retroceder() {
    this.anterior.emit();
  }

  isFormValid(): boolean {
    return !!(this.datosFisicos.peso && this.datosFisicos.estatura && this.datosFisicos.nivel_condicion_fisica);
  }
}
