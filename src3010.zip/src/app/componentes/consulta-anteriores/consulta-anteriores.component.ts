import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-consulta-anteriores',
  templateUrl: './consulta-anteriores.component.html',
  styleUrls: ['./consulta-anteriores.component.scss'],
})
export class ConsultaAnterioresComponent  implements OnInit {
  @Input() paciente: any; 
  constructor() { }

  ngOnInit() {}

}
