// src/app/shared/shared.module.ts
/* import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { provideCharts, withDefaultRegisterables } from 'ng2-charts';
import { GraficaTiempoRealComponent } from '../componentes/grafica-tiempo-real/grafica-tiempo-real.component';

@NgModule({
  declarations: [GraficaTiempoRealComponent],
  imports: [
    CommonModule,
    IonicModule,
  ],
  exports: [GraficaTiempoRealComponent],
  providers: [provideCharts(withDefaultRegisterables())],
})
export class SharedModule {} */
