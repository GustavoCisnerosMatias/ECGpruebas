import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { alertas } from '../interfaces/interface';
import { BehaviorSubject } from 'rxjs';
import { catchError, Observable, throwError } from 'rxjs';
import { GeneralService } from './general.service';
@Injectable({
  providedIn: 'root'
})
export class AlertasService {
  private baseUrl = this.servg.URLAPI;
  private alertasSubject = new BehaviorSubject<alertas[]>([]);
  public alertas$ = this.alertasSubject.asObservable();

  constructor(private http: HttpClient,private servg:GeneralService) {}

  obtenerAlertas(id_usuario: number): Observable<{ Alertas: alertas[] }> {
    return this.http.post<{ Alertas: alertas[] }>(`${this.baseUrl}/listaralertas`, { id_usuario });
  }

  actualizarVistaAlerta(id_alertas: number): Observable<any> {
    const payload = { id_alertas, vista: 'Visto' };
    return this.http.post(`${this.baseUrl}/actualizarVista`, payload);
  }

  cargarAlertas(id_usuario: number) {
    this.obtenerAlertas(id_usuario).subscribe(response => {
      this.alertasSubject.next(response.Alertas);
    });
  }

  /* guardarEstadoPaciente(payload: { id_alertas: number, descripcion: string }): Observable<any> {
    return this.http.post(`${this.baseUrl}/guardarestadopaciente`, payload);
  } */
  
  // Función para alertas_notas
  crearnotas_alertas(datosusuario: any): Observable<any> {
    console.log(datosusuario);
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post(`${this.baseUrl}/estado_alertasrel`, datosusuario, { headers }).pipe(
      catchError(this.handleError)
      
    );
  }
   // Método para obtener la lista de médicos
   obtenernotas(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/listanota`);
  }

  // Manejo de errores
  private handleError(error: any): Observable<never> {
    console.error('Ocurrió un error:', error);
    return throwError(error);
  }
}
