import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { GeneralService } from './general.service';
import { IMenu } from '../interfaces/interface';


@Injectable({
  providedIn: 'root'
})
export class MenuService {
  
  constructor(private http:HttpClient,private servG:GeneralService) { }

  getMenu(){
      let miUrl=this.servG.urlServidor+"menu.json";
      return this.http.get<IMenu[]>(miUrl);
  }
}
