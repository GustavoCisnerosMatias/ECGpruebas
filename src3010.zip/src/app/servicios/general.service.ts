import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})
export class GeneralService {

  constructor( private router:Router,private toastController: ToastController) { }
  URLAPI: string = 'http://localhost:8000/APILeccionP2'
  public urlServidor:string="/assets/BD/";
  irPagina(url:string){
    this.router.navigate([url]);
  }
  async mostrarMensajeExito(mensaje: string) {
    const toast = await this.toastController.create({
      message: mensaje,
      duration: 2000, // Duración del toast en milisegundos
      color: 'success' // Color del toast
    });
    toast.present(); // Muestra el toast en pantalla
  }

  async mostrarMensajeError(mensaje: string) {
    const toast = await this.toastController.create({
      message: mensaje,
      duration: 3000, // Duración del toast en milisegundos
      color: 'danger' // Color del toast
    });
    toast.present(); // Muestra el toast en pantalla
  }
}