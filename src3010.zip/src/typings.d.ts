declare module 'sockjs-client';
